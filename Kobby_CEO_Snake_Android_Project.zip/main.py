import os, math, random, wave
from array import array
from kivy.app import App
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle, RoundedRectangle, Ellipse, Line
from kivy.uix.widget import Widget
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label

# KOBBY CEO SNAKE GAME - Android / Kivy edition
# Finger swipe controls: swipe anywhere on the game board.

BG = (0.035, 0.055, 0.09, 1)
GREEN = (0.16, 0.9, 0.48, 1)
DARK_GREEN = (0.04, 0.52, 0.28, 1)
RED = (1, 0.25, 0.31, 1)
GOLD = (1, 0.76, 0.25, 1)
WHITE = (0.95, 0.97, 1, 1)
PANEL = (0.09, 0.13, 0.19, 1)

def synth_wav(path, duration, events, rate=22050):
    total = int(rate * duration)
    samples = array('f', [0.0]) * total
    for kind, start, length, freq, volume in events:
        first = max(0, int(start * rate))
        last = min(total, int((start + length) * rate))
        phase = 0.0
        for i in range(first, last):
            t = (i - first) / rate
            progress = t / length
            if kind == "noise":
                value = random.uniform(-1, 1)
                env = math.exp(-12 * progress)
            elif kind == "kick":
                phase += 2 * math.pi * freq * (1 - .55 * progress) / rate
                value = math.sin(phase)
                env = math.exp(-9 * progress)
            else:
                phase += 2 * math.pi * freq / rate
                value = math.sin(phase)
                env = math.exp((-7 if kind == "pluck" else -4) * progress)
            samples[i] += value * env * volume
    out = array('h')
    for v in samples:
        out.append(int(max(-1, min(1, v * .82)) * 32767))
    if os.sys.byteorder != "little":
        out.byteswap()
    with wave.open(path, "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(rate)
        f.writeframes(out.tobytes())

def make_audio_assets(folder):
    os.makedirs(folder, exist_ok=True)
    music = os.path.join(folder, "kobby_afrobeat.wav")
    eat = os.path.join(folder, "kobby_eat.wav")
    over = os.path.join(folder, "kobby_gameover.wav")
    if not os.path.exists(music):
        beat = .6
        ev = []
        for b in range(16):
            if b % 4 in (0, 2):
                ev.append(("kick", b*beat, .22, 85, .8))
            if b % 4 == 3:
                ev.append(("kick", b*beat+.25, .17, 75, .4))
        for b in (1,3,5,7,9,11,13,15):
            ev.append(("noise", b*beat, .18, 0, .38))
        for s in range(32):
            ev.append(("noise", s*beat/2, .045, 0, .12))
        bass = [55,55,65.4,73.4,55,82.4,73.4,65.4]
        melody = [220,261.6,293.7,329.6,293.7,261.6,392,329.6]
        for s in range(16):
            if s % 2 == 0 or s % 4 == 3:
                ev.append(("bass", s*beat, .27, bass[(s//2)%8], .28))
            if s % 2:
                ev.append(("pluck", s*beat, .23, melody[(s//2)%8], .14))
        synth_wav(music, beat*16, ev)
    if not os.path.exists(eat):
        synth_wav(eat, .5, [
            ("pluck", 0, .10, 880, .5),
            ("pluck", .09, .14, 1175, .45),
            ("pluck", .18, .18, 1568, .35)])
    if not os.path.exists(over):
        synth_wav(over, 1.4, [
            ("bass", 0, .35, 220, .4),
            ("bass", .28, .45, 164.8, .45),
            ("bass", .65, .65, 110, .5)])
    return music, eat, over

class SnakeBoard(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.cols = 20
        self.rows = 25
        self.snake = []
        self.direction = (1, 0)
        self.next_direction = (1, 0)
        self.food = (5, 5)
        self.score = 0
        self.highscore = 0
        self.state = "MENU"
        self.speed = .145
        self.accumulator = 0
        self.swipe_start = None
        self.music_on = True
        self.app_ref = None
        self.bind(pos=self.redraw, size=self.redraw)
        Clock.schedule_interval(self.update, 1/60)

    def board_rect(self):
        # Leave a header and footer for controls/status.
        margin = self.width * .045
        top_reserved = self.height * .17
        bottom_reserved = self.height * .12
        available_w = self.width - 2*margin
        available_h = self.height - top_reserved - bottom_reserved
        cell = min(available_w/self.cols, available_h/self.rows)
        w, h = cell*self.cols, cell*self.rows
        x = self.x + (self.width-w)/2
        y = self.y + bottom_reserved + (available_h-h)/2
        return x, y, cell, w, h

    def reset(self):
        self.snake = [(self.cols//2, self.rows//2),
                      (self.cols//2-1, self.rows//2),
                      (self.cols//2-2, self.rows//2)]
        self.direction = (1, 0)
        self.next_direction = (1, 0)
        self.score = 0
        self.speed = .145
        self.accumulator = 0
        self.spawn_food()
        self.state = "PLAYING"
        self.redraw()

    def spawn_food(self):
        while True:
            p = (random.randrange(self.cols), random.randrange(self.rows))
            if p not in self.snake:
                self.food = p
                return

    def set_direction(self, d):
        if d != (-self.direction[0], -self.direction[1]):
            self.next_direction = d

    def on_touch_down(self, touch):
        if not self.collide_point(*touch.pos):
            return super().on_touch_down(touch)
        self.swipe_start = touch.pos
        touch.grab(self)
        return True

    def on_touch_up(self, touch):
        if touch.grab_current is self:
            touch.ungrab(self)
            if self.swipe_start and self.state == "PLAYING":
                dx = touch.x - self.swipe_start[0]
                dy = touch.y - self.swipe_start[1]
                threshold = max(18, min(self.width, self.height) * .035)
                if max(abs(dx), abs(dy)) >= threshold:
                    if abs(dx) > abs(dy):
                        self.set_direction((1, 0) if dx > 0 else (-1, 0))
                    else:
                        self.set_direction((0, 1) if dy > 0 else (0, -1))
            self.swipe_start = None
            return True
        return super().on_touch_up(touch)

    def update(self, dt):
        if self.state != "PLAYING":
            return
        self.accumulator += dt
        if self.accumulator < self.speed:
            return
        self.accumulator = 0
        self.direction = self.next_direction
        hx, hy = self.snake[0]
        head = (hx+self.direction[0], hy+self.direction[1])
        eating = head == self.food
        body = self.snake if eating else self.snake[:-1]
        if (head[0] < 0 or head[0] >= self.cols or
            head[1] < 0 or head[1] >= self.rows or head in body):
            self.state = "OVER"
            if self.app_ref:
                self.app_ref.play_over()
            self.redraw()
            return
        self.snake.insert(0, head)
        if eating:
            self.score += 10
            self.speed = max(.065, self.speed-.003)
            if self.app_ref:
                self.app_ref.play_eat()
            if self.score > self.highscore:
                self.highscore = self.score
                if self.app_ref:
                    self.app_ref.save_highscore(self.highscore)
            self.spawn_food()
        else:
            self.snake.pop()
        self.redraw()

    def redraw(self, *args):
        self.canvas.clear()
        with self.canvas:
            Color(*BG)
            Rectangle(pos=self.pos, size=self.size)
            x, y, cell, bw, bh = self.board_rect()
            Color(*PANEL)
            RoundedRectangle(pos=(x-4, y-4), size=(bw+8, bh+8), radius=[12])
            # Subtle grid
            Color(.12, .17, .23, 1)
            for c in range(self.cols+1):
                xx = x+c*cell
                Line(points=[xx,y,xx,y+bh], width=.45)
            for r in range(self.rows+1):
                yy = y+r*cell
                Line(points=[x,yy,x+bw,yy], width=.45)
            if self.state in ("PLAYING", "PAUSED", "OVER"):
                fx = x+self.food[0]*cell
                fy = y+self.food[1]*cell
                Color(*RED)
                Ellipse(pos=(fx+cell*.18, fy+cell*.18),
                        size=(cell*.64, cell*.64))
                for i, (sx, sy) in enumerate(self.snake):
                    Color(*(GREEN if i == 0 else DARK_GREEN))
                    RoundedRectangle(
                        pos=(x+sx*cell+cell*.07, y+sy*cell+cell*.07),
                        size=(cell*.86, cell*.86),
                        radius=[max(3, cell*.22)])
        self.draw_overlay_text()

    def draw_overlay_text(self):
        # Labels are placed with Kivy widgets in the root layout.
        pass

class SnakeApp(App):
    def build(self):
        self.title = "KOBBY CEO SNAKE GAME"
        self.base = self.user_data_dir
        try:
            os.makedirs(self.base, exist_ok=True)
            music_path, eat_path, over_path = make_audio_assets(self.base)
            self.music = SoundLoader.load(music_path)
            self.eat = SoundLoader.load(eat_path)
            self.over = SoundLoader.load(over_path)
            if self.music:
                self.music.loop = True
                self.music.volume = .35
                self.music.play()
            if self.eat:
                self.eat.volume = .75
            if self.over:
                self.over.volume = .8
        except Exception as e:
            print("Audio setup:", e)
            self.music = self.eat = self.over = None

        self.high_file = os.path.join(self.base, "highscore.txt")
        try:
            with open(self.high_file) as f:
                self.best = int(f.read())
        except:
            self.best = 0

        root = BoxLayout(orientation="vertical", padding=8, spacing=5)
        self.header = Label(text="[b][color=FFC341]KOBBY CEO[/color][/b]\n[color=FFFFFF]SNAKE GAME • AFROBEATS EDITION[/color]",
                            markup=True, size_hint_y=None, height=72, font_size="20sp")
        root.add_widget(self.header)

        self.info = Label(text="", markup=True, size_hint_y=None, height=36, font_size="16sp")
        root.add_widget(self.info)

        self.board = SnakeBoard()
        self.board.app_ref = self
        self.board.highscore = self.best
        root.add_widget(self.board)

        controls = BoxLayout(size_hint_y=None, height=54, spacing=7)
        self.pause_btn = Button(text="PAUSE", font_size="15sp", background_normal="",
                                background_color=(.15,.35,.68,1))
        self.music_btn = Button(text="MUSIC ON", font_size="15sp", background_normal="",
                                background_color=(.12,.5,.34,1))
        restart_btn = Button(text="RESTART", font_size="15sp", background_normal="",
                             background_color=(.12,.5,.34,1))
        self.pause_btn.bind(on_release=self.pause_resume)
        self.music_btn.bind(on_release=self.toggle_music)
        restart_btn.bind(on_release=lambda *_: self.start_game())
        controls.add_widget(self.pause_btn)
        controls.add_widget(self.music_btn)
        controls.add_widget(restart_btn)
        root.add_widget(controls)

        self.action = Button(text="START GAME", size_hint_y=None, height=58,
                             font_size="20sp", bold=True, background_normal="",
                             background_color=(.10,.65,.36,1))
        self.action.bind(on_release=self.action_pressed)
        root.add_widget(self.action)

        self.board.state = "MENU"
        Clock.schedule_interval(self.refresh_labels, .1)
        return root

    def refresh_labels(self, dt):
        b = self.board
        self.info.text = (
            f"[color=35E682]SCORE: {b.score}[/color]      "
            f"[color=FFC341]BEST: {max(self.best,b.highscore)}[/color]"
        )
        if b.state == "MENU":
            self.action.text = "START GAME"
            self.pause_btn.text = "PAUSE"
        elif b.state == "PLAYING":
            self.action.text = "SWIPE TO STEER"
            self.pause_btn.text = "PAUSE"
        elif b.state == "PAUSED":
            self.action.text = "RESUME GAME"
            self.pause_btn.text = "RESUME"
        elif b.state == "OVER":
            self.action.text = "PLAY AGAIN"
            self.pause_btn.text = "PAUSE"

    def action_pressed(self, *_):
        if self.board.state in ("MENU", "OVER"):
            self.start_game()
        elif self.board.state == "PAUSED":
            self.board.state = "PLAYING"
            self.board.redraw()

    def start_game(self):
        self.board.reset()

    def pause_resume(self, *_):
        if self.board.state == "PLAYING":
            self.board.state = "PAUSED"
        elif self.board.state == "PAUSED":
            self.board.state = "PLAYING"
        self.board.redraw()

    def toggle_music(self, *_):
        if not self.music:
            return
        if self.music.state == "play":
            self.music.stop()
            self.music_btn.text = "MUSIC OFF"
        else:
            self.music.play()
            self.music_btn.text = "MUSIC ON"

    def play_eat(self):
        if self.eat and self.music and self.music.state == "play":
            self.eat.play()

    def play_over(self):
        if self.over and self.music and self.music.state == "play":
            self.over.play()

    def save_highscore(self, value):
        self.best = value
        try:
            with open(self.high_file, "w") as f:
                f.write(str(value))
        except:
            pass

if __name__ == "__main__":
    SnakeApp().run()
