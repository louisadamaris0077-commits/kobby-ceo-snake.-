KOBBY CEO SNAKE GAME — Android project

CONTROLS
- Swipe anywhere on the game board to steer.
- Swipe up/down/left/right to change direction.
- Use PAUSE, MUSIC ON/OFF, RESTART and START/RESUME buttons.

IMPORTANT
This project uses Kivy for Android packaging. Pydroid 3 is useful for Python testing,
but it does not directly create a distributable APK from this project.

BUILD APK
The included GitHub Actions workflow builds a debug APK in the cloud.
1. Create/sign in to GitHub.
2. Create a new repository, e.g. kobby-ceo-snake.
3. Upload all files and folders from this project ZIP to the repository.
4. Open the repository's Actions tab.
5. Run the workflow named "Build Android APK" (or push to main).
6. When it finishes, open the workflow run and download the artifact named
   kobby-ceo-snake-apk.
7. Extract the artifact ZIP to get the APK, then share the APK through WhatsApp.

The APK is a debug build for testing/sharing. For public Play Store release,
you will need a properly signed release build and Play Console setup.
