[app]
title = Kobby CEO Snake Game
package.name = kobbyceosnake
package.domain = com.kobbyceo
source.dir = .
source.include_exts = py,wav,txt,png,jpg,kv
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 1
android.permissions =
android.api = 35
android.minapi = 23
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
p4a.bootstrap = sdl2
